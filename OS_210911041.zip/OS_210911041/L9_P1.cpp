#include <bits/stdc++.h>
using namespace std;

void print_holes(vector<int>& holes) {
    int m = holes.size();
    for (int i = 0; i < m; i++) {
        cout << " " << i+1 << "\t\t" << holes[i] << "\n";
    }
}

void print_contents(vector<int>& processes, vector<int>& allocation, vector<int>& holes) {
    int n = processes.size();
    int m = holes.size();
    cout << "\nProcess ID.\tProcess Size\tAllocated Block ID\n";
    for (int i = 0; i < n; i++) {
        cout << " " << i+1 << "\t\t" << processes[i] << "\t\t";
        if (allocation[i] != -1)
            cout << allocation[i] + 1;
        else
            cout << "Not Allocated";
        cout << endl;
    }
    cout << endl;
    cout << "Holes after allocation : " << endl;
    print_holes(holes);
}

void first_fit(vector<int> holes, vector<int> processes) {
    int m = holes.size();
    int n = processes.size();
    vector<int> allocation(n, -1);

    cout << "Initial Holes: " << endl;
    print_holes(holes);

    for (int i = 0; i<n; i++) {
        for (int j = 0; j<m ; j++) {
            if (holes[j] >= processes[i]) {
                allocation[i] = j;
                holes[j] -= processes[i];
                break;
            }
        }
    }

    print_contents(processes, allocation, holes);
}

void best_fit(vector<int> holes, vector<int> processes) {
    int m = holes.size();
    int n = processes.size();
    vector<int> allocation(n, -1);

    cout << "Initial Holes: " << endl;
    print_holes(holes);

    for (int i = 0; i < n; i++) {
        int bestIdx = -1;
        for (int j = 0; j < m; j++) {
            if (holes[j] >= processes[i]) {
                if (bestIdx == -1)
                    bestIdx = j;
                else if (holes[bestIdx] > holes[j])
                    bestIdx = j;
            }
        }
        if (bestIdx != -1) {
            allocation[i] = bestIdx;
            holes[bestIdx] -= processes[i];
        }
    }
    print_contents(processes, allocation, holes);
}

int main() {

    int m, n;
    cout << "Enter total holes and total processes resp. : ";
    cin >> m >> n;
    vector<int> holes(m);
    vector<int> processes(n);
    cout << "Enter hole sizes : ";
    for (int i = 0; i<m; i++) {
        cin >> holes[i];
    }
    cout << "Enter process sizes : ";
    for (int i = 0; i<n; i++) {
        cin >> processes[i];
    }
    cout << "----------------------------------------------------------------" << endl;
    cout << "First Fit Algorithm : " << endl;
    cout << endl;
    first_fit(holes, processes);
    cout << "----------------------------------------------------------------" << endl;
    cout << "Best Fit Algorithm : " << endl;
    cout << endl;
    best_fit(holes, processes);
    cout << "----------------------------------------------------------------" << endl;

    return 0;
}
