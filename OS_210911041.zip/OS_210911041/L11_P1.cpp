#include <bits/stdc++.h>
using namespace std;

void display(vector<int> seek_seq, int seek_cnt) {
    cout << "Total seek operations : " << seek_cnt << endl;
    cout << "Seek Sequence : ";
    for (int x : seek_seq)
        cout << x << " ";
    cout << endl;
    cout << endl;
}

int findMin(int diff[][2], int n) {
    int idx = -1, min = INT_MAX;
    for (int i = 0; i<n; i++) {
        if (!diff[i][1] && min > diff[i][0]) {
            min = diff[i][0];
            idx = i;
        }
    }
    return idx;
}

void SSTF(vector<int>& request, int head, int n) {
    if (n == 0)
        return;
    int diff[n][2] = {{0, 0}};
    int seek_cnt = 0;
    vector<int> seek_seq(n + 1, 0);

    for (int i = 0; i<n; i++) {
        seek_seq[i] = head;
        for (int i = 0; i<n; i++) 
            diff[i][0] = abs(head - request[i]);
        int idx = findMin(diff, n);
        diff[idx][1] = 1;
        seek_cnt += diff[idx][0];
        head = request[idx];
    }
    seek_seq[n] = head;
    display(seek_seq, seek_cnt);
}

void calc(vector<int>& seek_seq, int& cur_track, int& distance, int& head, int& seek_cnt) {
    seek_seq.push_back(cur_track);
    distance = abs(cur_track - head);
    seek_cnt += distance;
    head = cur_track;
}

void SCAN(vector<int> arr, int head, string dir, int disk_size) {
    int seek_count = 0, distance, cur_track, size = arr.size();
    vector<int> left, right,seek_seq;
 
    if (dir == "left")
        left.push_back(0);
    else if (dir == "right")
        right.push_back(disk_size - 1);
 
    for (int i = 0; i < size; i++) {
        if (arr[i] < head)
            left.push_back(arr[i]);
        if (arr[i] > head)
            right.push_back(arr[i]);
    }
 
    sort(left.begin(), left.end());
    sort(right.begin(), right.end());

    int run = 2;
    while (run--) {
        if (dir == "left") {
            for (int i = left.size() - 1; i >= 0; i--) {
                cur_track = left[i];
                calc(seek_seq, cur_track, distance, head, seek_count);
            }
            dir = "right";
        }
        else if (dir == "right") {
            for (int i = 0; i < right.size(); i++) {
                cur_track = right[i];
                calc(seek_seq, cur_track, distance, head, seek_count);
            }
            dir = "left";
        }
    }
    display(seek_seq, seek_count);
}

void CSCAN(vector<int> arr, int head, int disk_size) {
    int seek_cnt = 0, distance, cur_track, size = arr.size();
    vector<int> left, right, seek_seq;

    left.push_back(0);
    right.push_back(disk_size - 1);
  
    for (int i = 0; i < size; i++) {
        if (arr[i] < head)
            left.push_back(arr[i]);
        if (arr[i] > head)
            right.push_back(arr[i]);
    }
  
    sort(left.begin(), left.end());
    sort(right.begin(), right.end());

    for (int i = 0; i < right.size(); i++) {
        cur_track = right[i];
        calc(seek_seq, cur_track, distance, head, seek_cnt);
    }
    head = 0;
    seek_cnt += (disk_size - 1);
    for (int i = 0; i < left.size(); i++) {
        cur_track = left[i];
        calc(seek_seq, cur_track, distance, head, seek_cnt);
    }

    display(seek_seq, seek_cnt);
}
  
void CLOOK(vector<int> arr, int head, int disk_size) {
    int seek_cnt = 0, size = arr.size(), distance, cur_track;
    vector<int> left, right, seek_seq;
    for (int i = 0; i < size; i++) {
        if (arr[i] < head)
            left.push_back(arr[i]);
        if (arr[i] > head)
            right.push_back(arr[i]);
    }
 
    sort(left.begin(), left.end());
    sort(right.begin(), right.end());
 
    for (int i = 0; i < right.size(); i++) {
        cur_track = right[i];
        calc(seek_seq, cur_track, distance, head, seek_cnt);
    }
    seek_cnt += abs(head - left[0]);
    head = left[0];
    for (int i = 0; i < left.size(); i++) {
        cur_track = left[i];
        calc(seek_seq, cur_track, distance, head, seek_cnt);
    }

    display(seek_seq, seek_cnt);
}

int main() {

    int n, disk_size, head;
    cout << "Enter number of requests : ";
    cin >> n;
    cout << "Enter requests : ";
    vector<int> req(n);
    for (int i = 0; i < n; i++)
        cin >> req[i];
    cout << "Enter size and head pointer : ";
    cin >> disk_size >> head;
    int ch;
    cout << endl;
    cout << "Disk Scheduling ALgorithms : " << endl;
    cout << "1. Shortest Seek Time First (SSTF)" << endl;
    cout << "2. SCAN" << endl;
    cout << "3. C-SCAN" << endl;
    cout << "4. C-LOOK" << endl;
    cout << "5. Exit" << endl;
    do {
        cout << endl;
        cout << "Enter your choice: ";
        cin >> ch;
        switch(ch) {
            case 1: {
                cout << "Shortest Seek Time First (SSTF)" << endl;
                SSTF(req, head, n);
                break;
            }
            case 2: {
                string dir;
                cout << "Enter direction : ";
                cin >> dir;
                cout << "SCAN" << endl;
                SCAN(req, head, dir, disk_size);
                break;
            }
            case 3: {
                cout << "CSCAN" << endl;
                CSCAN(req, head, disk_size);
                break;
            }
            case 4: {
                cout << "CLOOK" << endl;
                CLOOK(req, head, disk_size);
                break;
            }
            case 5: {
                cout << "Program terminated" << endl;
                break;
            }
        }
    } while (ch != 5);

    return 0;
}