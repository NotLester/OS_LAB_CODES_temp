for file in $@;do
rm -i $file
done
echo "done"