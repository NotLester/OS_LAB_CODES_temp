cp $1 $2
echo "done"