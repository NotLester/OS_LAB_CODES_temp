declare -a arr
i=0
for k in $@; do
 arr[$((i++))]=$k
done
n=$#
for((i=0;i<n-1;i++));do
	for((j=0;j<n-i-1;j++));do
		if [ ${arr[$j]}>${arr[$j+1]} ];then
			temp=${arr[$j]}
			arr[$j]=${arr[$j+1]}
			arr[$j+1]=$temp
		fi
	done
done
echo "sorted list:"
for((i=0;i<n;i++));do
	echo "${arr[$i]}"
done
