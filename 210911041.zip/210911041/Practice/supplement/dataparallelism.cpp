#include <pthread.h>
#include <iostream>
#include <stdlib.h>
using namespace std;

// used for synchronization
pthread_mutex_t lock;

// global variable visible to all threads
int sum = 0;

// Define the max threads as X per the cores in your system
#define maxThread  2

// Array
#define N 1000000
int arr[N];

// Function to find the sum of large array with the a thread, pass the min and maximum index so that the thread can handle only that data. Find the local sum and then use pthread_mutex_lock to add it to the global sum variable
void *threadSum(void* arg)
{
    int thread_id = *(int*)arg;
    int start = thread_id * (N / maxThread);
    int end = (thread_id + 1) * (N / maxThread);

    int local_sum = 0;
    for (int i = start; i < end; i++) {
        local_sum += arr[i];
    }

    pthread_mutex_lock(&lock);
    sum += local_sum;
    pthread_mutex_unlock(&lock);

    return NULL;
}

int main()
{
    int i;

    // Read N (number of elements) and create an array of N random numbers
    srand(time(NULL));
    for (i = 0; i < N; i++) {
        arr[i] = rand() % 100;
    }

    // Write a loop to find the sum of N elements sequentially and display the sum and time taken
    sum = 0;
    clock_t start_time = clock();
    for (i = 0; i < N; i++) {
        sum += arr[i];
    }
    clock_t end_time = clock();
    cout << "Sequential sum = " << sum << endl;
    cout << "Sequential time taken = " << (double)(end_time - start_time) / CLOCKS_PER_SEC << " seconds" << endl;

    // Now divide the N as per maxThread and create threads with corresponding indices for sum
    sum = 0;
    pthread_t threads[maxThread];

    // creating maxThread threads
    int thread_id[maxThread];
    for (i = 0; i < maxThread; i++) {
        thread_id[i] = i;
        pthread_create(&threads[i], NULL, threadSum, &thread_id[i]);
    }

    // i.e. waiting for threads to complete
    for (i = 0; i < maxThread; i++) {
        pthread_join(threads[i], NULL);
    }

    // Display final sum and time taken
    cout << "Parallel sum = " << sum << endl;
    cout << "Parallel time taken = " << (double)(clock() - end_time) / CLOCKS_PER_SEC << " seconds" << endl;

    return 0;
}
