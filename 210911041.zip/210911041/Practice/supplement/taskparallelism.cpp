#include<stdio.h>
#include<pthread.h>
#include <unistd.h>
#include <sys/wait.h>
#include <signal.h>
//Thread Function declaration

int main(int argc,char**argv)
{

    pthread_t tid_long;
    printf("\nInside main thread before computation \n");
//Write the code for a linear and binary search  of "50" in 3000 random integers and display the time taken for the search.

//Write the code for the creation of two threads for performing the above linear search using the LinearSearch and BinarySearch  function. Read the documentation for pthread_create, pthread_cancel, and pthread_join.  Display the time taken for the search.

// Analyse the code with different input array size

}

void *LinearSearch(void *arg)
{
//Write the code for linear search  of 50 in random 3000 integers
    return NULL;

}

void *BinarySearch(void *arg)
{
    //Write the code for Binary Search of 50 in random 3000 integers
    return NULL;

}
