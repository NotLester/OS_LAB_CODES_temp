#include <iostream>
using namespace std;

int main() {
	int p, r, x, y, z;
	
	// Number of processes
	p = 4;
	
	// Number of resources
	r = 4;
	/*
		List P0, P1, P2 and P3
		for allotment matrix
	*/
	int allotment[4][4] = { 
		{ 0, 0, 1, 2 },
		{ 1, 0, 0, 0},
		{ 1, 3, 5, 4 },
		{ 0, 6, 3, 2 } };
   
	/*
		List P0, P1, P2 and P3
		for maximum matrix
	*/
	int maximum[4][4] = { 
		{ 0, 0, 1, 2 },
		{ 1, 7, 5, 0 },
		{ 2, 3, 5, 6 },
		{ 0, 6, 5, 2 } };
	
	// Available Resources
	int available[4] = { 1, 5, 2, 0 };
	
	int f[p], res[p], ind = 0;
	for (z = 0; z < p; z++) {
		f[z] = 0;
	}
	
	int requirement[p][r];
	for (x = 0; x < p; x++) {
		for (y = 0; y < r; y++)
		requirement[x][y] = maximum[x][y] - allotment[x][y];
	}

	int a = 0;
	for (z = 0; z < 4; z++) {
		for (x = 0; x < p; x++) {
			if (f[x] == 0) {
				int flag = 0;
				for (y = 0; y < r; y++) {
					if (requirement[x][y] > available[y]) {
						flag = 1;
						break;
					}
				}
				if (flag == 0) {
					res[ind++] = x;
					for (a = 0; a < r; a++)
					available[a] += allotment[x][a];
					f[x] = 1;
				}
			}
		}
	}
	
	int flag = 1;
	/*
		Sequence is not safe or not
		based on the number of asked requirement
	*/
	for(int x = 0; x<p; x++) {
		if(f[x]==0) {
			flag = 0;
			break;
		}
	}
	if(flag==1) {
		cout << "Safe Sequence" << endl;
		for (x = 0; x < p - 1; x++)
		cout << " P" << res[x] << " ->";
		cout << " P" << res[p - 1] <<endl;
	}
	return (0);
}