#include <stdio.h>
#include <pthread.h>
#include <unistd.h>
#include <sys/wait.h>
#include <signal.h>
#include <time.h>
#include <stdlib.h>
#include <iostream>
using namespace std;

#define ARRAY_SIZE 3000

int arr[ARRAY_SIZE];

// Function declarations
void *linearSearch(void *arg);
void *binarySearch(void *arg);

int main(int argc, char **argv) {
    pthread_t tid_linear, tid_binary;
    int target = 50;
    clock_t start, end;
    double cpu_time_used;

    // Initialize array with random integers
    srand(time(NULL));
    for (int i = 0; i < ARRAY_SIZE; i++) {
        arr[i] = rand() % 100;
    }

    cout<<"Inside main thread before computation\n";

    // Linear Search
    start = clock();
    pthread_create(&tid_linear, NULL, linearSearch, &target);
    pthread_join(tid_linear, NULL);
    end = clock();

    cpu_time_used = ((double) (end - start)) / CLOCKS_PER_SEC;
    cout<< "Linear search took " << cpu_time_used << " time\n";

    // Binary Search
    start = clock();
    pthread_create(&tid_binary, NULL, binarySearch, &target);
    pthread_join(tid_binary, NULL);
    end = clock();

    cpu_time_used = ((double) (end - start)) / CLOCKS_PER_SEC;
    cout<< "Binary search took " <<cpu_time_used << " time\n";

    return 0;
}

void *linearSearch(void *arg) {
    int target = *((int *)arg);
    int found = 0;

    cout<< "Inside linear search thread\n";

    for (int i = 0; i < ARRAY_SIZE; i++) {
        if (arr[i] == target) {
            cout<< "Linear search found target "<<target<< " at index " << i <<endl;
            found = 1;
            break;
        }
    }

    if (!found) {
        cout<< "Linear search did not find target "<< target <<endl;
    }

    return NULL;
}

void *binarySearch(void *arg){
    int target = *((int *)arg);
    int low = 0, high = ARRAY_SIZE - 1, mid;
    int found = 0;

    cout<< "Inside binary search thread\n";

    while (low <= high){
        mid = (low + high) / 2;
        if (arr[mid] == target) {
            cout<< "Binary search found target " <<target << " at index "<< mid<<endl;
            found = 1;
            break;
        }
        else if (arr[mid] < target) {
            low = mid + 1;
        }
        else {
            high = mid - 1;
        }
    }

    if (!found) {
        cout<< "Binary search did not find target "<<target<< endl;
    }

    return NULL;
}
