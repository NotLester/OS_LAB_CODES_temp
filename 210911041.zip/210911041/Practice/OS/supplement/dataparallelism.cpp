#include <pthread.h>
#include <iostream>
#include <stdlib.h>
#include <time.h>
#include <chrono>

using namespace std;
using namespace std::chrono;

//used for synchronization
pthread_mutex_t lock;

//global variables visible to all threads
int *arr;
int N;
int sum = 0;

// Define the max threads as X per the cores in your system
#define maxThread  2

// Function to find the sum of a large array with a thread, pass the min and maximum index so that the thread can handle only that data.
// Find the local sum and then use pthread_mutex_lock to add it to the global sum variable
void *threadSum(void* arg) {
    int thread_id = *(int*) arg;
    int start = thread_id * (N / maxThread);
    int end = (thread_id + 1) * (N / maxThread);

    int local_sum = 0;
    for (int i = start; i < end; i++) {
        local_sum += arr[i];
    }

    pthread_mutex_lock(&lock);
    sum += local_sum;
    pthread_mutex_unlock(&lock);

    return NULL;
}

int main() {
    // Read N (number of elements) and create an array of N random numbers
    cout << "Enter the number of elements: ";
    cin >> N;

    arr = new int[N];
    srand(time(0));
    for (int i = 0; i < N; i++) {
        arr[i] = rand() % 100;
    }

    // Write a loop to find the sum of N elements sequentially and display the sum and time taken
    auto start_seq = high_resolution_clock::now();
    int seq_sum = 0;
    for (int i = 0; i < N; i++) {
        seq_sum += arr[i];
    }
    auto stop_seq = high_resolution_clock::now();

    auto duration_seq = duration_cast<microseconds>(stop_seq - start_seq);
    cout << "Sequential Sum: " << seq_sum << endl;
    cout << "Time taken sequentially: " << duration_seq.count() << " microseconds" << endl;

    sum = 0;

    // Now divide the N as per maxThread and create threads with corresponding indices for sum
    pthread_t threads[maxThread];
    int thread_id[maxThread];

    // creating maxThread threads
    auto start_par = high_resolution_clock::now();
    for (int i = 0; i < maxThread; i++) {
        thread_id[i] = i;
        pthread_create(&threads[i], NULL, threadSum, (void*) &thread_id[i]);
    }

    // i.e. waiting for threads to complete
    for (int i = 0; i < maxThread; i++) {
        pthread_join(threads[i], NULL);
    }
    auto stop_par = high_resolution_clock::now();

    auto duration_par = duration_cast<microseconds>(stop_par - start_par);
    cout << "Parallel Sum: " << sum << endl;
    cout << "Time taken in parallel: " << duration_par.count() << " microseconds" << endl;

    delete[] arr;

    return 0;
}
