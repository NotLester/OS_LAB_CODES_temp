#include <iostream>
#include <semaphore.h>
#include <pthread.h>
#include <cstdlib>

#define BUFFER_SIZE 10

pthread_mutex_t mutex;
pthread_t tidP[100], tidC[100];
sem_t full, empty;
int counter;
int buffer[BUFFER_SIZE];

void initialize() {
    pthread_mutex_init(&mutex, nullptr);
    sem_init(&full, 1, 0);
    sem_init(&empty, 1, BUFFER_SIZE);
    counter = 0;
}

void write(int item) {
    if (counter < BUFFER_SIZE) {
        buffer[counter++] = item;
    } else {
        std::cout << "\nError: buffer overflow\n" << std::endl;
    }
}

int read() {
    if (counter > 0) {
        return(buffer[--counter]);
    } else {
        std::cout << "\nError: buffer underflow\n" << std::endl;
        return -1;
    }
}


void *producer(void *param) {
    int waittime, item, i;
    item = rand()%5;
    waittime = rand()%5;
    sem_wait(&empty);
    pthread_mutex_lock(&mutex);
    std::cout << "\nProducer has produced item: " << item << std::endl;
    write(item);
    pthread_mutex_unlock(&mutex);
    sem_post(&full);
    return nullptr;
}

void *consumer(void *param) {
    int waittime, item;
    waittime = rand()%5;
    sem_wait(&full);
    pthread_mutex_lock(&mutex);
    item = read();
    std::cout << "\nConsumer has consumed item: " << item << std::endl;
    pthread_mutex_unlock(&mutex);
    sem_post(&empty);
    return nullptr;
}

int main() {
    int n1, n2, i;
    initialize();
    std::cout << "\nEnter no. of producers: ";
    std::cin >> n1;
    std::cout << "\nEnter no. of consumers: ";
    std::cin >> n2;
    for(i=0;i<n1;i++)
        pthread_create(&tidP[i], nullptr, producer, nullptr);
    for(i=0;i<n2;i++)
        pthread_create(&tidC[i], nullptr, consumer, nullptr);
    for(i=0;i<n1;i++)
        pthread_join(tidP[i], nullptr);
    for(i=0;i<n2;i++)
        pthread_join(tidC[i], nullptr);

    return 0;
}
