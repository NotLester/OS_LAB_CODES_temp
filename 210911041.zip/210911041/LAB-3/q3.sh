#!/bin/sh

for file in *.txt; do 
        mv  "$file" "${file%.txt}.text"
done

for dir in ./*/;do
    (cd "$dir" &&
    for file in *.txt; do 
        mv -- "$file" "${file%.txt}.text"
    done
    )
done