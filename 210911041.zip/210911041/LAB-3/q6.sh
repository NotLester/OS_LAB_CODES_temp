#!/bin/bash

sed -i -e `s/^ex:/Example:/` *.txt
sed -i -e `s/\.ex:/\Example:/` *.txt

cat fi.txt