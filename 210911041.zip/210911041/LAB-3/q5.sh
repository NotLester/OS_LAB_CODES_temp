#!/bin/sh

echo "Enter file extensions"
read extension
echo "enter dir name"
read dir
result = `find .-maxdepth 1-name "*extension"`
mkdir $folder
for i in $result
do
	mv $ i folder
done
echo "all files with given extension moved"
