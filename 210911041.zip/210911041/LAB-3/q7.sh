#!/bin/sh

echo "Enter file"
read file
sed -i 'O-2d' $file
cat $file