#!/bin/sh

echo "Enter filename to be searched"
read string
echo "Enter path"
read path
echo "Matched files: "
ls $path/*$string*
