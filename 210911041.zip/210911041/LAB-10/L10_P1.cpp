#include <bits/stdc++.h>
using namespace std;

int fifo(vector<int> reference_string, int num_frames) {
    deque<int> frames;
    int num_faults = 0;
    bool fault = false;

    for (int i = 0; i < reference_string.size(); i++) {
        int page = reference_string[i];
        if (find(frames.begin(), frames.end(), page) == frames.end()) {
            if (frames.size() < num_frames) {
                frames.push_back(page);
                fault = true;
            } else {
                frames.pop_front();
                frames.push_back(page);
                fault = true;
            }
            num_faults++;
        } else {
            fault = false;
        }
        cout << "Page : " << reference_string[i] << "   "
            << "Contents : ";
        for (auto x : frames)
            cout << x << " ";
        cout << "\t";
        if (!fault)
            cout << "Page Hit" << endl;
        else
            cout << "Page Fault" << endl;
    }

    return num_faults;
}

int predict(vector<int>& ref_string, vector<int>& frames, int n, int idx) {
    int res = -1, farthest = idx, j;
    for (int i = 0; i < frames.size(); i++) {
        for (j = idx; j < n; j++) {
            if (frames[i] == ref_string[j]) {
                if (j > farthest) {
                    farthest = j;
                    res = i;
                }
                break;
            }
        }
        if (j == n)
            return i;
    }
    return (res == -1) ? 0 : res;
}

void print_contents(vector<int>& frames, bool fault, int x) {
    cout << "Page : " << x << "   "
         << "Contents : ";
    for (auto x : frames)
        cout << x << " ";
    cout << "\t";
    if (!fault)
        cout << "Page Hit" << endl;
    else
        cout << "Page Fault" << endl;
}

int optimal(vector<int>& ref_string, int frame_size) {
    bool fault = 0;
    int n = ref_string.size(), hit = 0;
    vector<int> frames;
    
    for (int i = 0; i < n; i++) {
        if (find(frames.begin(), frames.end(), ref_string[i]) != frames.end()) {
            hit++;
            fault = 0;
            print_contents(frames, fault, ref_string[i]);
            continue;
        }
        fault = 1;
        if (frames.size() < frame_size) {
            frames.push_back(ref_string[i]);
        }
        else {
            int idx = predict(ref_string, frames, n, i + 1);
            frames[idx] = ref_string[i];
        }
        print_contents(frames, fault, ref_string[i]);
    }

    return n - hit;
}

int main() {
    int num_frames, num_pages;
    vector<int> reference_string;

    cout << "Enter the number of frames: ";
    cin >> num_frames;

    cout << "Enter number of pages : ";
    cin >> num_pages;

    cout << "Enter the reference string: ";
    for (int i = 0; i < num_pages; i++) {
        int page;
        cin >> page;
        reference_string.push_back(page);
    }

    cout << "---------------------------------------------------------" << endl;
    cout << "FIFO Page Replacement Algorithm" << endl;
    int num_faults_fifo = fifo(reference_string, num_frames);
    cout << "Total page faults : " << num_faults_fifo << endl;
    cout << "---------------------------------------------------------" << endl;

    cout << endl;
    cout << "Optimal Page Replacement Algorithm" << endl;
    int num_faults_optimal = optimal(reference_string, num_frames);
    cout << "Total page faults : " << num_faults_optimal << endl;
    cout << "---------------------------------------------------------" << endl;

    return 0;
}
