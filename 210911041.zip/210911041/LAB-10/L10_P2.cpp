#include <bits/stdc++.h>
using namespace std;

void insertIfElementNotFound(deque<int>& dq, int& page_faults, bool& fault, int pages[], int i) {
    dq.push_back(pages[i]);
    page_faults++;
    fault = 1;
}

void insertIfElementFound(deque<int>& dq, bool& fault, int pages[], int i) {
    dq.erase(find(dq.begin(), dq.end(), pages[i]));
    dq.push_back(pages[i]);
    fault = 0;
}

bool checkIfPageNotPresent(deque<int>& dq, int pages[], int i) {
    return find(dq.begin(), dq.end(), pages[i]) == dq.end();
}

void print_contents(deque<int>& dq, int x, bool fault) {
    cout << "Page: " << x << "  Frame: ";
    deque<int> temp = dq;
    while (!temp.empty()) {
        cout << temp.front() << " ";
        temp.pop_front();
    }
    cout << "\t ";
    if (!fault)
        cout << "Page Hit" << endl;
    else
        cout << "Page Fault" << endl;
}

int LRU(int pages[], int n, int capacity) {
    deque<int> dq;
    int page_faults = 0;
    bool fault;

    for (int i = 0; i < n; i++) {

        if (dq.size() < capacity) {
            if (checkIfPageNotPresent(dq,pages,i)) 
                insertIfElementNotFound(dq, page_faults, fault, pages, i);
            
            else 
                insertIfElementFound(dq,fault,pages, i);
        }

        // If the deque is full, perform LRU
        else {
            if (checkIfPageNotPresent(dq,pages,i)) {
                dq.pop_front();
                insertIfElementNotFound(dq, page_faults, fault, pages, i);
            }
            else 
                insertIfElementFound(dq,fault,pages, i);
        }

        print_contents(dq, pages[i], fault);
    }

    return page_faults;
}

int main() {

    int n, capacity;
    cout << "Enter the number of pages: ";
    cin >> n;
    int pages[n];
    cout << "Enter the pages: ";
    for (int i = 0; i < n; i++)
        cin >> pages[i];
    cout << "Enter the size of the frame: ";
    cin >> capacity;

    cout << endl;
    cout << "Implementing LRU Page Replacement Algorithm" << endl;
    cout << "------------------------------------------" << endl;
    int page_faults = LRU(pages, n, capacity);
    cout << "------------------------------------------" << endl;

    cout << "Total Page Faults: " << page_faults << endl;
    cout << "Total Page Hits: " << n - page_faults << endl;
    cout << "Hit Ratio : " << (float) (n-page_faults) / n << endl;
    cout << endl;


    return 0;
}
