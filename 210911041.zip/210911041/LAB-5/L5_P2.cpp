#include <iostream>
#include <unistd.h>
#include <string.h>
#include <sys/types.h>
#include <sys/wait.h>


using namespace std;

int main(int argc, char **argv) {

	pid_t child = fork();
	pid_t *status;

	if(child == 0) {
		cout<< "Child Process: " <<endl;
		cout<< "Sorted Strings";
		for(int i = 1; i < argc - 1; i++) {
			for(int j = i + 1; j < argc; j++) {
				if(strcmp(argv[i], argv[j]) > 0) {
					swap(argv[i],argv[j]);
				}
			}
		}
		
		for(int i = 1; i < argc; i++){
			cout<< argv[i] << " ";
		}
		cout<< endl;
	}

	else if(child > 0) {
		wait(status);
		cout<< "Parent Process: " <<endl;
		cout<< "Unsorted Strings";
		for(int i = 0; i < argc; i++){
			cout<< argv[i] <<endl;
		}
		cout<< endl;
	}

	else {
		cout<< "Fork Failed" <<endl;
	}

	return 0;
}