#include<iostream>
#include<sys/types.h>
#include<unistd.h>
#include<sys/wait.h>
#include<stdlib.h>
#include<string.h>

using namespace std;

void swap(char a[100],char b[100])
{
    char c[100];
    strcpy(c,a);
    strcpy(a,b);
    strcpy(b,c);
}

int main() {
    char str[100][100];
    int i,j,n,x;
    
    cout<< "Enter no. of strings: " <<endl;
    cin>> n;

    cout<< "Enter strings: "<<endl;
    
    for(int i = 0 ; i < n ; i++) {
      cin>> str[i];
    }
    
    pid_t p = fork();
    
    if(p == 0) {
       cout<< "Using Bubble Sort" <<endl;
       
        for(i=0;i<n;i++) {
            for(j=0;j<n-i-1;j++) {
                if(strcmp(str[j],str[j+1])>0) {
                    swap(str[j],str[j+1]);
                }
            }
       }

       for(i = 0 ; i < n ; i++) {
           cout<< str[i] << " ";
        }
        cout<<endl;
        exit(0);
    } 
    else {
      
      wait(&i);
      pid_t p2 = fork();
      
      if(p2 == 0) {
         
        int pos,large;

        cout<< "Selection sort" <<endl;
         
        for(i = 0 ; i < n ; i++) { 
            
            pos=i,large=0;
            for(j=i;j<n;j++) {

                if(x = strcmp(str[i],str[j]) > large) {
                    large=x;
                    pos=j;
                }
            }
            
            swap(str[i],str[pos]);
        }
              
        
       for(i = 0 ; i < n ; i++) {
            cout<< str[i] << " ";
        }
        cout<< endl;
    
    } 
    else {
        wait(&i);
        cout<< "Unsorted :" <<endl;
        for(i=0;i<n;i++) {
            cout<< str[i] <<" ";
        }
        cout<<endl;
        wait(&i);
    }

}

    return 0;
}



// Enter no. of strings: 4
// Enter strings: mit manipal lester lewis
// Using Bubble Sort
// lester lewis manipal mit 
// Selection sort
// manipal lester lewis mit 
// Unsorted :
// mit manipal lester lewis 