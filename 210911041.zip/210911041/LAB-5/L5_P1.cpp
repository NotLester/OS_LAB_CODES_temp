#include<unistd.h>
#include<stdlib.h>
#include<stdio.h>
#include <iostream>

using namespace std;

int main()
{
	pid_t fork_return=fork();

	if(fork_return == 0) {
		cout<< "Child Process: " <<endl;
    cout<< "PID: " <<getpid() <<" " << "PPID: "<<getppid() <<endl;
  }
	else if(fork_return > 0) {
    cout<<"Parent Process: " <<endl;
    cout<< "PID: " <<getpid() <<" " << "PPID: "<<getppid() <<endl;    
  }

	return 0;
}