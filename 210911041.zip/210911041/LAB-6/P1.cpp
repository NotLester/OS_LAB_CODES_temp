#include <iostream>
#include <vector>
#include <queue>
#include <algorithm>

using namespace std;

struct Process {
    int pid;
    int arrivalTime;
    int burstTime;
    int priority;
    int remainingTime;
    int waitingTime;
    int turnaroundTime;
};

// Comparison function for priority queue in non-preemptive priority scheduling
struct ComparePriority {
    bool operator()(const Process& p1, const Process& p2) {
        return p1.priority < p2.priority;
    }
};

// Comparison function for sorting processes by arrival time
bool sortByArrivalTime(const Process& p1, const Process& p2) {
    return p1.arrivalTime < p2.arrivalTime;
}

void displayTable(const vector<Process>& processes) {
    int n = processes.size();
    int totalWaitingTime = 0, totalTurnaroundTime = 0;
    cout << "------------------------------------------------------------------------" << endl;
    cout << "PID\tArrival Time\tBurst Time\tPriority\tWaiting Time\tTurnaround Time" << endl;
    cout << "------------------------------------------------------------------------" << endl;
    for (int i = 0; i < n; i++) {
        cout << processes[i].pid << "\t";
        cout << processes[i].arrivalTime << "\t\t";
        cout << processes[i].burstTime << "\t\t";
        cout << processes[i].priority << "\t\t";
        cout << processes[i].waitingTime << "\t\t";
        cout << processes[i].turnaroundTime << endl;
        totalWaitingTime += processes[i].waitingTime;
        totalTurnaroundTime += processes[i].turnaroundTime;
    }
    cout << "------------------------------------------------------------------------" << endl;
    cout << "Average waiting time: " << (float)totalWaitingTime / n << endl;
    cout << "Average turnaround time: " << (float)totalTurnaroundTime / n << endl;
    cout << "------------------------------------------------------------------------" << endl;
}

void preemptiveSJF(vector<Process>& processes) {
    int n = processes.size();
    priority_queue<pair<int, int>, vector<pair<int, int>>, greater<pair<int, int>>> pq; // pair of remaining time and pid
    int currTime = 0;
    int completedProcesses = 0;
    int prevPid = -1;
    while (completedProcesses < n) {
        // Push all processes that arrive at or before current time into priority queue
        for (int i = 0; i < n; i++) {
            if (processes[i].arrivalTime <= currTime && processes[i].remainingTime > 0 && processes[i].pid != prevPid) {
                pq.push({processes[i].remainingTime, processes[i].pid});
            }
        }
        if (pq.empty()) {
            currTime++;
            continue;
        }
        // Get process with shortest remaining time
        int pid = pq.top().second;
        pq.pop();
        if (processes[pid].remainingTime == processes[pid].burstTime) {
            processes[pid].waitingTime = currTime - processes[pid].arrivalTime;
        }
        processes[pid].remainingTime--;
        currTime++;
        prevPid = pid;
        if (processes[pid].remainingTime == 0) {
            processes[pid].turnaroundTime = currTime - processes[pid].arrivalTime;
            completedProcesses++;
        }
    }
    displayTable(processes);
}


void roundRobin(vector<Process>& processes, int quantum) {
    int n = processes.size();
    queue<int> q; // queue of pids
    int currTime = 0;
    int completedProcesses = 0;
    int prevPid = -1;
    int remainingTime[n];
    for (int i = 0; i < n; i++) {
        remainingTime[i] = processes[i].burstTime;
    }
    while (completedProcesses < n) {
        // Push all processes that arrive at or before current time into queue
        for (int i = 0; i < n; i++) {
            if (processes[i].arrivalTime <= currTime && remainingTime[i] > 0 && processes[i].pid != prevPid) {
                q.push(processes[i].pid);
            }
        }
        if (q.empty()) {
            currTime++;
            continue;
        }
        // Get next process from queue
        int pid = q.front();
        q.pop();
        if (processes[pid].remainingTime == processes[pid].burstTime) {
            processes[pid].waitingTime = currTime - processes[pid].arrivalTime;
        }
        if (remainingTime[pid] > quantum) {
            currTime += quantum;
            remainingTime[pid] -= quantum;
            q.push(pid);
        } else {
            currTime += remainingTime[pid];
            processes[pid].remainingTime = 0;
            remainingTime[pid] = 0;
            processes[pid].turnaroundTime = currTime - processes[pid].arrivalTime;
            completedProcesses++;
        }
        prevPid = pid;
    }
    displayTable(processes);
}

void nonPreemptivePriority(vector<Process>& processes) {
    int n = processes.size();
    sort(processes.begin(), processes.end(), ComparePriority()); // sort processes by priority
    int currTime = 0;
    int completedProcesses = 0;
    while (completedProcesses < n) {
        if (processes[completedProcesses].arrivalTime > currTime) {
            currTime = processes[completedProcesses].arrivalTime;
        }
        processes[completedProcesses].waitingTime = currTime - processes[completedProcesses].arrivalTime;
        currTime += processes[completedProcesses].burstTime;
        processes[completedProcesses].turnaroundTime = currTime - processes[completedProcesses].arrivalTime;
        completedProcesses++;
    }
    displayTable(processes);
}

int main() {
    int n;
    cout << "Enter the number of processes: ";
    cin >> n;
    vector<Process> processes(n);
    for (int i = 0; i < n; i++) {
        processes[i].pid = i;
        cout << "Enter the arrival time, burst time, and priority of process " << i << ": ";
        cin >> processes[i].arrivalTime >> processes[i].burstTime >> processes[i].priority;
        processes[i].remainingTime = processes[i].burstTime;
    }
    sort(processes.begin(), processes.end(), sortByArrivalTime);
    int choice;
    do {
            cout << "--------------------------------------------"<<endl;
            cout << "Select a scheduling algorithm to run:" << endl;
    cout << "1. Preemptive Shortest Job First" << endl;
    cout << "2. Round Robin" << endl;
    cout << "3. Non-preemptive Priority Scheduling" << endl;
    cout << "4. Exit" << endl;
    cout << "Enter your choice: ";
    cin >> choice;
    switch (choice) {
        case 1:
            preemptiveSJF(processes);
            break;
        case 2:
            int quantum;
            cout << "Enter the time quantum for Round Robin: ";
            cin >> quantum;
            roundRobin(processes, quantum);
            break;
        case 3:
            nonPreemptivePriority(processes);
            break;
        case 4:
            cout << "Exiting program." << endl;
            break;
        default:
            cout << "Invalid choice. Please try again." << endl;
    }
} while (choice != 4);
return 0;
}

